<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->user  = $this->session->userdata("user");
    }

    public function index(){
        if($this->user){
            redirect(base_url('anasayfa'));
        }
        $data = array(
            'title' => 'Giriş Yap'
        );
        $this->load->view('login', $data);
    }

    public function dashboard(){
        if(!$this->user){
            redirect(base_url());
        }
        $data = array(
            'title' => 'Anasayfa',
            'i' => $this->admin_model->counter() 
        );
        $this->load->view('dashboard', $data);
    }

    public function addPost(){
        if(!$this->user){
            redirect(base_url());
        }
        $data = array(
            'title' => 'İçerik Ekle',
            'categories' => $this->admin_model->getData('categories')
        );
        $this->load->view('add-post', $data); 
    }

    public function posts(){
        if(!$this->user){
            redirect(base_url());
        }
        $data = array(
            'title' => 'İçerikler',
            'posts' => $this->admin_model->getPosts()
        );
        $this->load->view('posts', $data); 
    }

    public function contacts(){
        if(!$this->user){
            redirect(base_url());
        }
        $data = array(
            'title' => 'Mesajlar',
            'contacts' => $this->admin_model->getData('contacts')
        );
        $this->load->view('contacts', $data); 
    }

    public function comments(){
        if(!$this->user){
            redirect(base_url());
        }
        $data = array(
            'title' => 'Yorumlar',
            'comments' => $this->admin_model->getComments()
        );
        $this->load->view('comments', $data); 
    }

    
    public function settings(){
        if(!$this->user){
            redirect(base_url());
        }
        $data = array(
            'title' => 'Ayarlar',
            'i' => $this->admin_model->getDataByID('settings', 1)
        );
        $this->load->view('settings', $data); 
    }

    public function updatesetting(){
        $facebook = $this->input->post('facebook');
        $twitter = $this->input->post('twitter');
        $instagram = $this->input->post('instagram');
        $about = $this->input->post('about');

        $data = array(
            'facebook' => $facebook,
            'twitter' => $twitter,
            'instagram' => $instagram,
            'about' => $about
        );

        $update = $this->admin_model->updateData('settings', 1, $data);

        if($update){
            $alert = array(
                'message' => 'Ayarlar başarıyla güncellendi',
                'type' => 'success'
            );
        }else{
            $alert = array(
                'message' => 'Opps! Teknik bir hata oluştu',
                'type' => 'danger'
            );
        }

        $this->session->set_flashdata('alert', $alert);
        redirect($this->agent->referrer());


    }

    public function users(){
        if(!$this->user){
            redirect(base_url());
        }
        $data = array(
            'title' => 'Kullanıcılar',
            'users' => $this->admin_model->getData('users')
        );
        $this->load->view('users', $data); 
    }

    public function updatePst($id){
        if(!$this->user){
            redirect(base_url());
        }
        $data = array(
            'title' => 'İçerik Düzenle',
            'categories' => $this->admin_model->getData('categories'),
            'post' => $this->admin_model->getDataByID('posts', $id)
        );
        $this->load->view('update-post', $data); 
    }

    public function updateLogo(){
        $logo = $_FILES['image']['name'];
        if($logo){
            $config = array(
                'upload_path' => 'uploads/logo/',
                'allowed_types' => 'gif|jpg|png|svg|jpeg',
                'max_size' => 4096
            );
            $this->load->library('upload', $config);
            $upload = $this->upload->do_upload('image');
            if($upload){
                $data = array(
                    'logo' =>  base_url('uploads/logo/').$this->upload->data("file_name")
                );
                $update = $this->admin_model->updateData('settings', 1, $data);

                if($update){
                    $alert = array(
                        'message' => 'Logo başarıyla güncellendi',
                        'type' => 'success'
                    );
                }else{
                    $alert = array(
                        'message' => 'Opps! Teknik bir hata oluştu',
                        'type' => 'danger'
                    );
                }
            }else{
                $alert = array(
                    'message' => 'Sadece .gif | .jpg | .png | .svg | .jpeg uzantısına sahip dosyalar yüklenebilir',
                    'type' => 'danger'
                );  
            }
        }else{
            $alert = array(
                'message' => 'Lütfen bir logo seçiniz',
                'type' => 'info'
            );   
        }
        $this->session->set_flashdata('alert', $alert);
        redirect($this->agent->referrer());
    }

    public function updatePost($id){
        $title = $this->input->post('title');
        $category = $this->input->post('category');
        $image = $_FILES['image']['name'];
        $content = $this->input->post('content');

        if($image){
            $config = array(
                'upload_path' => 'uploads/post-img/',
                'allowed_types' => 'gif|jpg|png|svg|jpeg',
                'max_size' => 4096
            );
            $this->load->library('upload', $config);
            $upload = $this->upload->do_upload('image');
            if($upload){
                $data = array(
                    'categoryID' => $category,
                    'title' => $title,
                    'slug' => $this->tools->str_slug($title),
                    'img' => base_url('uploads/post-img/').$this->upload->data("file_name"),
                    'content' => $content,
                    'createdAt' => date('Y-m-d H:i:s')
                );
            }else{
                $alert = array(
                    'message' => 'Sadece .gif | .jpg | .png | .svg | .jpeg uzantısına sahip dosyalar yüklenebilir',
                    'type' => 'danger'
                );  
            }
        }else{
            $data = array(
                'categoryID' => $category,
                'title' => $title,
                'slug' => $this->tools->str_slug($title),
                'content' => $content,
                'createdAt' => date('Y-m-d H:i:s')
            );
        }

        $update = $this->admin_model->updateData('posts',$id, $data);

        if($update){
            $alert = array(
                'message' => 'İçerik başarıyla güncellendi',
                'type' => 'success'
            );
            $this->session->set_flashdata('alert', $alert);
            redirect(base_url('icerikler'));
        }else{
            $alert = array(
                'message' => 'Opps! Teknik bir hata oluştu',
                'type' => 'danger'
            );
        }

        $this->session->set_flashdata('alert', $alert);
        redirect($this->agent->referrer());
    }

    public function addPst(){
        $title = $this->input->post('title');
        $category = $this->input->post('category');
        $image = $_FILES['image']['name'];
        $content = $this->input->post('content');

        if($title && $category && $image && $content){
            $config = array(
                'upload_path' => 'uploads/post-img/',
                'allowed_types' => 'gif|jpg|png|svg|jpeg',
                'max_size' => 4096
            );
            $this->load->library('upload', $config);
            $upload = $this->upload->do_upload('image');
            if($upload){
                $data = array(
                    'categoryID' => $category,
                    'title' => $title,
                    'slug' => $this->tools->str_slug($title),
                    'img' => base_url('uploads/post-img/').$this->upload->data("file_name"),
                    'content' => $content,
                    'createdAt' => date('Y-m-d H:i:s')
                );
                $insert = $this->admin_model->insertData('posts', $data);
                if($insert){
                    $alert = array(
                        'message' => 'İçerik başarıyla eklendi',
                        'type' => 'success'
                    );
                    $this->session->set_flashdata('alert', $alert);
                    redirect(base_url('icerikler'));
                }else{
                    $alert = array(
                        'message' => 'Opps! Teknik bir hata oluştu',
                        'type' => 'danger'
                    );
                }
            }else{
                $alert = array(
                    'message' => 'Sadece .gif | .jpg | .png | .svg | .jpeg uzantısına sahip dosyalar yüklenebilir',
                    'type' => 'danger'
                );  
            }
        }else{
            $alert = array(
                'message' => 'Lütfen boş alan bırakmayın',
                'type' => 'primary'
            );
        }
        $this->session->set_flashdata('alert', $alert);
        redirect($this->agent->referrer());
    }

    
    public function addCategory(){
        if(!$this->user){
            redirect(base_url());
        }
        $data = array(
            'title' => 'Kategori Ekle',
        );
        $this->load->view('add-category', $data);
    }

    public function categories(){
        if(!$this->user){
            redirect(base_url());
        }
        $data = array(
            'title' => 'Kategoriler',
            'categories' => $this->admin_model->getData('categories')
        );
        $this->load->view('categories', $data);
    }

    public function updateCategory($id){
        if(!$this->user){
            redirect(base_url());
        }
        $category = $this->admin_model->getDataByID('categories',$id);
        $data = array(
            'title' => 'Kategori Düzenle',
            'category' => $category
        );
        $this->load->view('update-category', $data);
    }

    public function addCat(){
        $name = $this->input->post('name');
        if($name){
            $data = array(
                'name' => $name,
                'slug' => $this->tools->str_slug($name)
            );
            $insert = $this->admin_model->insertData('categories', $data);
            if($insert){
                $alert = array(
                    'message' => 'Kategori başarıyla eklendi',
                    'type' => 'success'
                );  
                $this->session->set_flashdata('alert', $alert);
                redirect(base_url('kategoriler'));
            }else{
                $alert = array(
                    'message' => 'Opps! Teknik bir hata oluştu',
                    'type' => 'danger'
                );
            }
        }else{
            $alert = array(
                'message' => 'Lütfen kategori ismi giriniz',
                'type' => 'primary'
            );
        }
        $this->session->set_flashdata('alert', $alert);
        redirect($this->agent->referrer());
    }

    public function updateCat($id){
        $name = $this->input->post('name');
        if($name){
            $data = array(
                'name' => $name,
                'slug' => $this->tools->str_slug($name)
            );
            $update = $this->admin_model->updateData('categories',$id, $data);
            if($update){
                $alert = array(
                    'message' => 'Kategori başarıyla güncellendi',
                    'type' => 'success'
                );
                $this->session->set_flashdata('alert', $alert);
                redirect(base_url('kategoriler'));  
            }else{
                $alert = array(
                    'message' => 'Opps! Teknik bir hata oluştu',
                    'type' => 'danger'
                );
            }
        }else{
            $alert = array(
                'message' => 'Lütfen kategori ismi giriniz',
                'type' => 'primary'
            );
        }
        $this->session->set_flashdata('alert', $alert);
        redirect($this->agent->referrer());
    }

    public function login(){
        $email = $this->input->post('email');
        $password = $this->input->post('password');

        if($email && $password){
            $where= array('email' => $email, 'password' => $password);
            $checkLogin = $this->admin_model->checkLogin($where);
            if($checkLogin->num_rows() > 0){
                $userInfo = $checkLogin->row();
                if($userInfo->role == 1){
                    $user = array(
                        'id' => $userInfo->id,
                        'name' => $userInfo->name,
                        'surname' => $userInfo->surname,
                        'email' => $userInfo->email
                    );
                    $this->session->set_userdata('user', $user);
                    redirect(base_url('anasayfa'));
                }else{
                    $alert = array(
                        'message' => 'Yönetim paneline erişim yetkiniz yok',
                        'type' => 'warning'
                    ); 
                }

            }else{
                $alert = array(
                    'message' => 'Email veya şifre yanlış',
                    'type' => 'danger'
                ); 
            }
        }else{
            $alert = array(
                'message' => 'Lütfen boş alan bırakmayın',
                'type' => 'primary'
            );
        }
        $this->session->set_flashdata('alert', $alert);
        redirect($this->agent->referrer());
    }

    public function logout(){
        $this->session->sess_destroy();
        $this->session->unset_userdata("user");
        redirect(base_url());
    }

    public function delete($id, $tblName){
        $delete = $this->admin_model->delete($id, $tblName);
        if($delete){
            $alert = array(
                'message' => 'İşlem başarıyla gerçekletirildi',
                'type' => 'success'
            );
        }else{
            $alert = array(
                'message' => 'Opps! Teknik bir hata oluştu',
                'type' => 'danger'
            ); 
        }
        $this->session->set_flashdata('alert', $alert);
        redirect($this->agent->referrer());
    }
}