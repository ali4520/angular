<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . '/libraries/REST_Controller.php';
class Api extends CI_Controller {

	public $JSON_DATA;

	public function __construct(){
		parent::__construct();
		$this->output->set_content_type("application/json");
		$this->output->set_header("Access-Control-Allow-Origin: *");
		$this->output->set_header("Access-Control-Allow-Methods: GET, OPTIONS");
		$this->output->set_header("Access-Control-Allow-Headers: Content-Type, Content-Length, Accept-Encoding");
		
		$this->JSON_DATA = (array)json_decode(file_get_contents("php://input"));
	}

	public function getCategories()
	{
		 $this->db_model->categories();
	}	

	public function getCategoryBySlug($slug)
	{
		$this->db_model->getCategoryBySlug($slug);
	}

	public function getCategoryPosts($id)
	{
		 $this->db_model->getCategoryPosts($id);
	}

	public function getSettings()
	{
		 $this->db_model->getSettings();
	}

	public function sliderPost(){
		$this->db_model->sliderPost();
	}

	public function getAllPost(){
		 $this->db_model->getAllPost();
	}

	public function getPostDetail($slug){
		 $this->db_model->getPostDetail($slug);
	}

	public function getRecommended(){
		 $this->db_model->getRecommended();
	}

	public function limitedCategory(){
		 $this->db_model->limitedCategory();
	}

	public function getComments($slug){
		$this->db_model->getComments($slug);
	}

	public function register(){
		$name = $this->JSON_DATA['name'];
		$surname = $this->JSON_DATA['surname'];
		$email = $this->JSON_DATA['email'];
		$password = $this->JSON_DATA['password'];
		$username = $this->JSON_DATA['username'];
		$checkUsername = $this->db_model->checkUsername($username);
		$checkEmail = $this->db_model->checkEmail($email);
		if($checkUsername > 0){
			$response = array(
				'type' => 'ualready',
				'message' => $username.' isimli bir kullanıcı zaten mevcut'
			);
		}else{
			if($checkEmail > 0){
				$response = array(
					'type' => 'ealready',
					'message' => $email.' email adresine ait bir hesap zaten mevcut'
				);
			}else{
				$data = array(
					'username' => $username,
					'email' => $email,
					'password' => $password,
					'name' => $name,
					'surname' => $surname,
					'role' => 0
				);

				$insert = $this->db_model->register($data);
				if($insert){
					$response = array(
						'type' => 'okey',
						'message' => 'Hesabınız başarıyla oluşturuldu'
					);
				}else{
					$response = array(
						'type' => 'error',
						'message' => 'Teknik bir hata oluştu'
					);
				}
			}
		}

		echo json_encode($response);


	}

	public function login(){
		if(empty($this->JSON_DATA['username']) && empty($this->JSON_DATA['password'])){
			$response = array(
				'type' => 'empty',
				'message' => 'Lütfen kullanıcı adı ve şifreyi giriniz'
			);
		}else{
			$checkInfo = $this->db_model->checkLoginInfo($this->JSON_DATA['username'],$this->JSON_DATA['password']); 
			if($checkInfo->num_rows() > 0){
				$tokenData = array(
					'id' => $checkInfo->row()->id,
					'username' => $checkInfo->row()->username,
					'name' => $checkInfo->row()->name,
					'surname' => $checkInfo->row()->surname
				);
				$output = AUTHORIZATION::generateToken($tokenData);
				$response = array(
					'type' => 'success',
					'token' => $output,
					'message' => 'Hoşgeldiniz, '.ucfirst($checkInfo->row()->name).' '.ucfirst($checkInfo->row()->surname)
				);
			}else{
				$response = array(
					'type' => 'error',
					'message' => 'Kullanıcı adı veya şifre yanlış'
				);
			}
		}
		
		echo json_encode($response);
	}

	public function sendComment(){
		$userID = $this->JSON_DATA['userID'];
		$postID = $this->JSON_DATA['postID'];
		$comment = $this->JSON_DATA['text'];
		$data = array(
			'postID' => $postID,
			'userID' => $userID,
			'comment' => $comment,
			'status' => 1,
			'createdAt' => date('Y-m-d H:i:s')
		);
		$insert = $this->db_model->sendComment($data);
		if($insert){
			$response = array(
				'message' => 'Yorumunuz başarıyla gönderildi.',
				'type' => 'okey'
			);
		}else{
			$response = array(
				'type' => 'error',
				'message' => 'Teknik bir hata oluştu'
			);
		}

		echo json_encode($response);
	}

	public function sendContact(){
		$data = array(
			'email' => $this->JSON_DATA['email'],
			'subject' => $this->JSON_DATA['subject'],
			'message' => $this->JSON_DATA['message'],
			'createdAt' => date('Y-m-d H:i:s')
		);
		$insert = $this->db_model->sendContact($data);
	}


}
