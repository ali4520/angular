<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_model extends CI_Model{

    public function checkLogin($where){
        $query = $this->db->where($where)->get('users');
        return $query;
    }

    public function counter(){
        $return['postCount'] = $this->db->count_all_results('posts');
        $return['userCount'] = $this->db->count_all_results('users');
        $return['commentCount'] = $this->db->count_all_results('comments');
        $return['contactCount'] = $this->db->count_all_results('contacts');

        return $return;
    }

    public function getData($tblName){
        $query = $this->db->order_by('id', 'DESC')->get($tblName)->result();
        return $query;
    }

    public function insertData($tblName, $data){
        $query = $this->db->insert($tblName, $data);
        return $query;
    }

    public function getDataByID($tblName, $id){
        $query = $this->db->where('id', $id)->get($tblName)->row();
        return $query;
    }

    public function updateData($tblName, $id, $data){
        $query = $this->db->where('id', $id)->update($tblName, $data);
        return $query;
    }

    public function delete($id, $tblName){
        $query = $this->db->where('id', $id)->delete($tblName);
        return $query;
    }

    public function getPosts(){
        $query = $this->db->join('categories', 'posts.categoryID = categories.id')->select('posts.*, categories.name as categoryName')
        ->order_by('createdAt', 'DESC')->get('posts')->result();
        return $query;
    }

    public function getComments(){
        $query = $this->db->join('posts', 'comments.postID = posts.id')->join('users', 'comments.userID = users.id')->select('comments.*, users.username as username, posts.title as postTitle, posts.img as postIMG')
            ->order_by('comments.createdAt', 'DESC')->get('comments');
        return $query->result();
    }



}