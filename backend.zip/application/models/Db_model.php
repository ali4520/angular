<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Db_model extends CI_Model{

    public function categories()
    {
        $query = $this->db->get('categories')->result();
        return $this->output->set_status_header(200)->set_content_type('application/json', 'utf-8')
        ->set_output(json_encode($query, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    }

    public function getCategoryBySlug($slug)
    {
        $query = $this->db->where('slug', $slug)->get('categories')->row();
        return $this->output->set_status_header(200)->set_content_type('application/json', 'utf-8')
        ->set_output(json_encode($query, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    }

    public function getCategoryPosts($id)
    {
        $this->db->join('categories', 'posts.categoryID = categories.id');
        $this->db->select('posts.*, categories.name as categoryName, categories.slug as categorySlug');
        $this->db->where('posts.categoryID', $id);
        $this->db->order_by('posts.createdAt', 'DESC');
        $query = $this->db->get('posts')->result();
        return $this->output->set_status_header(200)->set_content_type('application/json', 'utf-8')
        ->set_output(json_encode($query, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));

    }

    public function getSettings(){
        $query = $this->db->where('id', 1)->get('settings')->row();
        return $this->output->set_status_header(200)->set_content_type('application/json', 'utf-8')
        ->set_output(json_encode($query, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    }

    public function sliderPost(){
        $this->db->join('categories', 'posts.categoryID = categories.id');
        $this->db->select('posts.*, categories.name as categoryName, categories.slug as categorySlug');
        $this->db->order_by('posts.createdAt', 'DESC');
        $this->db->limit(2);
        $query = $this->db->get('posts')->result();
        return $this->output->set_status_header(200)->set_content_type('application/json', 'utf-8')
        ->set_output(json_encode($query, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    }

    public function getAllPost(){
        $this->db->join('categories', 'posts.categoryID = categories.id');
        $this->db->select('posts.*, categories.name as categoryName, categories.slug as categorySlug');
        $this->db->order_by('posts.createdAt', 'DESC');
        $query = $this->db->get('posts')->result();
        return $this->output->set_status_header(200)->set_content_type('application/json', 'utf-8')
        ->set_output(json_encode($query, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    }

    public function getPostDetail($slug){
        $this->db->join('categories', 'posts.categoryID = categories.id');
        $this->db->select('posts.*, categories.name as categoryName, categories.slug as categorySlug');
        $this->db->where('posts.slug', $slug);
        $query = $this->db->get('posts')->row();
        return $this->output->set_status_header(200)->set_content_type('application/json', 'utf-8')
        ->set_output(json_encode($query, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    }



    public function getRecommended(){
        $this->db->join('categories', 'posts.categoryID = categories.id');
        $this->db->select('posts.*, categories.name as categoryName, categories.slug as categorySlug');
        $this->db->order_by('posts.id', 'RANDOM');
        $this->db->limit(2);
        $query = $this->db->get('posts')->result();
        return $this->output->set_status_header(200)->set_content_type('application/json', 'utf-8')
        ->set_output(json_encode($query, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    }

    public function limitedCategory(){
        $this->db->order_by('id', 'RANDOM');
        $this->db->limit(4);
        $query = $this->db->get('categories')->result();
        return $this->output->set_status_header(200)->set_content_type('application/json', 'utf-8')
        ->set_output(json_encode($query, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    }

    public function getComments($slug){
        $postID = $this->db->where('slug', $slug)->get('posts')->row();
        
        $this->db->join('users', 'comments.userID = users.id');
        $this->db->select('comments.*, users.name as name, users.surname as surname, users.username as username');
        $this->db->where('comments.postID', $postID->id);
        $this->db->where('comments.status', 1);
        $this->db->order_by('comments.createdAt', 'DESC');
        $query = $this->db->get('comments')->result();
        return $this->output->set_status_header(200)->set_content_type('application/json', 'utf-8')
        ->set_output(json_encode($query, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    }

    public function checkUsername($username){
        $query = $this->db->where('username', $username)->get('users')->num_rows();
        return $query;
    }

    public function checkEmail($email){
        $query = $this->db->where('email', $email)->get('users')->num_rows();
        return $query;
    }

    public function checkLoginInfo($username, $password){
        $query = $this->db->where(array('username' => $username, 'password' => $password))->get('users');
        return $query;
    }

    public function sendComment($data){
        $query = $this->db->insert('comments', $data);
        return $query;
    }

    public function register($data){
        $query = $this->db->insert('users', $data);
        return $query;
    }

    public function sendContact($data){
        $query = $this->db->insert('contacts', $data);
        return $query;
    }

}
