<?php $this->load->view('inc/top'); ?>
<?php $alert = $this->session->userdata("alert");?>
<div id="layoutSidenav">
    <?php $this->load->view('inc/left-menu'); ?>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid">
                <h1 class="mt-4">Ayarlar</h1>
                <?php if($alert):?>
                <div class="alert alert-<?=$alert['type'];?>" role="alert">
                    <?=$alert['message'];?>
                </div>
                <?php endif; ?>
                <div class="row">
                    <div class="col-xl-8">
                        <div class="card mb-4">
                            <div class="card-header">Ayarlar</div>
                            <div class="card-body">
                                <form action="<?=base_url('admin/updatesetting');?>" method="POST">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Facebook</label>
                                        <input type="text" class="form-control" id="exampleInputEmail1"
                                            aria-describedby="emailHelp" name="facebook" value="<?=$i->facebook?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Twitter</label>
                                        <input type="text" class="form-control" id="exampleInputEmail1"
                                            aria-describedby="emailHelp" name="twitter" value="<?=$i->twitter?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Instagram</label>
                                        <input type="text" class="form-control" id="exampleInputEmail1"
                                            aria-describedby="emailHelp" name="instagram" value="<?=$i->instagram?>">
                                    </div>

                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Hakkımızda</label>
                                        <textarea name="about" id="about" rows="10"
                                            class="form-control"><?=$i->about?></textarea>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Güncelle</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4">
                        <div class="card mb-4">
                            <div class="card-header">Logo Ekle</div>
                            <div class="card-body">
                                <form action="<?=base_url('admin/updateLogo');?>" method="POST"
                                    enctype="multipart/form-data">
                                    <?php if($i->logo): ?>
                                    <div class="form-group">
                                        <label>Mevcut Logo : </label>
                                        <img src="<?=$i->logo?>" style="width: 114; height:18px;">
                                    </div>
                                    <?php endif; ?>
                                    <div class="form-group">
                                        <label for="exampleFormControlFile1">Logo [114 x 18]</label>
                                        <input type="file" class="form-control-file" name="image"
                                            id="exampleFormControlFile1">
                                    </div>
                                    <button type="submit" class="btn btn-primary">Güncelle</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>
<?php $this->load->view('inc/bottom');?>