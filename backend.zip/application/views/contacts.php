<?php $this->load->view('inc/top'); ?>
<?php $alert = $this->session->userdata("alert");?>
<div id="layoutSidenav">
    <?php $this->load->view('inc/left-menu'); ?>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid">
                <h1 class="mt-4">Mesajlar</h1>
                <div class="card mb-4">
                    <div class="card-header"><i class="fas fa-table mr-1"></i>Mesajlar</div>
                    <div class="card-body">
                        <?php if($alert):?>
                        <div class="alert alert-<?=$alert['type'];?>" role="alert">
                            <?=$alert['message'];?>
                        </div>
                        <?php endif; ?>
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>Email</th>
                                        <th>Konu</th>
                                        <th>Mesaj</th>
                                        <th>İşlem</th>
                                    </tr>
                                </thead>
                                <tfoot>
                                    <tr>
                                        <th>Email</th>
                                        <th>Konu</th>
                                        <th>Mesaj</th>
                                        <th>İşlem</th>
                                    </tr>
                                </tfoot>
                                <tbody>
                                    <?php foreach($contacts as $row): ?>
                                    <tr>
                                        <td><?=$row->email?></td>
                                        <td><?=$row->subject?></td>
                                        <td><?=$row->message;?></td>
                                        <td>
                                            <a href="<?=base_url('admin/delete/'.$row->id.'/contacts');?>"
                                                class="btn btn-danger" style="color: #fff">Sil</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>
<?php $this->load->view('inc/bottom');?>