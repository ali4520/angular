<div id="layoutSidenav_nav">
    <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
        <div class="sb-sidenav-menu">
            <div class="nav">
                <div class="sb-sidenav-menu-heading">İşlemler</div>
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseLayouts"
                    aria-expanded="false" aria-controls="collapseLayouts">
                    <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                    Kategori
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapseLayouts" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link" href="<?=base_url('kategori-ekle')?>">
                            Kategori Ekle
                        </a>
                        <a class="nav-link" href="<?=base_url('kategoriler')?>">Kategoriler</a>
                    </nav>
                </div>

                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#icerik"
                    aria-expanded="false" aria-controls="icerik">
                    <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                    İçerik
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="icerik" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link" href="<?=base_url('icerik-ekle')?>">
                            İçerik Ekle
                        </a>
                        <a class="nav-link" href="<?=base_url('icerikler')?>">İçerikler</a>
                    </nav>
                </div>
                <a class="nav-link" href="<?=base_url('kullanicilar')?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-user"></i></div>
                    Kullanıcılar
                </a>
                <a class="nav-link" href="<?=base_url('mesajlar')?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-envelope"></i></div>
                    Mesajlar
                </a>
                <a class="nav-link" href="<?=base_url('yorumlar')?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-comments"></i></div>
                    Yorumlar
                </a>
                <a class="nav-link" href="<?=base_url('ayarlar')?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-cogs"></i></div>
                    Ayarlar
                </a>
            </div>
        </div>
    </nav>
</div>