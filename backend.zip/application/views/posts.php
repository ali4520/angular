<?php $this->load->view('inc/top'); ?>
<?php $alert = $this->session->userdata("alert");?>
<div id="layoutSidenav">
    <?php $this->load->view('inc/left-menu'); ?>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid">
                <h1 class="mt-4">Kategori</h1>
                <div class="card mb-4">
                    <div class="card-header"><i class="fas fa-table mr-1"></i>Kategoriler</div>
                    <div class="card-body">
                        <?php if($alert):?>
                        <div class="alert alert-<?=$alert['type'];?>" role="alert">
                            <?=$alert['message'];?>
                        </div>
                        <?php endif; ?>
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>Resim</th>
                                        <th>Kategori</th>
                                        <th>Başlık</th>
                                        <th>İşlem</th>
                                    </tr>
                                </thead>
                                <tfoot>
                                    <tr>
                                        <th>Resim</th>
                                        <th>Kategori</th>
                                        <th>Başlık</th>
                                        <th>İşlem</th>
                                    </tr>
                                </tfoot>
                                <tbody>
                                    <?php foreach($posts as $row): ?>
                                    <tr>
                                        <td>
                                            <img src="<?=$row->img?>" style="width: 48px; height: 48px;">
                                        </td>
                                        <td><?=$row->categoryName?></td>
                                        <td><?=$row->title?></td>
                                        <td>
                                            <a href="<?=base_url('icerik-duzenle/'.$row->id)?>" class="btn btn-primary"
                                                style="color: #fff">Düzenle</a>
                                            <a href="<?=base_url('admin/delete/'.$row->id.'/posts');?>"
                                                class="btn btn-danger" style="color: #fff">Sil</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>
<?php $this->load->view('inc/bottom');?>