<?php $this->load->view('inc/top'); ?>
<?php $alert = $this->session->userdata("alert");?>
<div id="layoutSidenav">
    <?php $this->load->view('inc/left-menu'); ?>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid">
                <h1 class="mt-4">Kategori</h1>
                <div class="row">
                    <div class="col-xl-8">
                        <div class="card mb-4">
                            <div class="card-header">Kategori Ekle</div>
                            <div class="card-body">
                                <?php if($alert):?>
                                <div class="alert alert-<?=$alert['type'];?>" role="alert">
                                    <?=$alert['message'];?>
                                </div>
                                <?php endif; ?>
                                <form action="<?=base_url('admin/addCat');?>" method="POST">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Kategori adı</label>
                                        <input type="text" class="form-control" id="exampleInputEmail1"
                                            aria-describedby="emailHelp" name="name" placeholder="Kategori adı">
                                    </div>
                                    <button type="submit" class="btn btn-primary">Ekle</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>
<?php $this->load->view('inc/bottom');?>