<?php $this->load->view('inc/top'); ?>
<?php $alert = $this->session->userdata("alert");?>
<div id="layoutSidenav">
    <?php $this->load->view('inc/left-menu'); ?>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid">
                <h1 class="mt-4">İçerik</h1>
                <div class="row">
                    <div class="col-xl-12">
                        <div class="card mb-4">
                            <div class="card-header">İçerik Ekle</div>
                            <div class="card-body">
                                <?php if($alert):?>
                                <div class="alert alert-<?=$alert['type'];?>" role="alert">
                                    <?=$alert['message'];?>
                                </div>
                                <?php endif; ?>
                                <form action="<?=base_url('admin/addPst');?>" method="POST" enctype="multipart/form-data">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Başlık</label>
                                        <input type="text" class="form-control" id="exampleInputEmail1" name="title"
                                            placeholder="Başlık">
                                    </div>
                                    <div class="form-group">
                                        <select class="custom-select" name="category">
                                            <option value="" selected>Kategori seçiniz</option>
                                            <?php foreach($categories as $row): ?>
                                            <option value="<?=$row->id?>"><?=$row->name?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleFormControlFile1">Resim</label>
                                        <input type="file" class="form-control-file" name="image" id="exampleFormControlFile1">
                                    </div>

                                    <div class="form-group">
                                        <label>İçerik</label>
                                        <textarea name="content" id="editor1" rows="10" cols="80">
                                            Gelişmiş elemanları bulunan metin alanı
                                        </textarea>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Ekle</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>
<?php $this->load->view('inc/bottom');?>