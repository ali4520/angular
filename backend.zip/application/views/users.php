<?php $this->load->view('inc/top'); ?>
<?php $alert = $this->session->userdata("alert");?>
<div id="layoutSidenav">
    <?php $this->load->view('inc/left-menu'); ?>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid">
                <h1 class="mt-4">Kullanıcılar</h1>
                <div class="card mb-4">
                    <div class="card-header"><i class="fas fa-table mr-1"></i>Kullanıcılar</div>
                    <div class="card-body">
                        <?php if($alert):?>
                        <div class="alert alert-<?=$alert['type'];?>" role="alert">
                            <?=$alert['message'];?>
                        </div>
                        <?php endif; ?>
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>Kullanıcı adı</th>
                                        <th>Ad</th>
                                        <th>Soyad</th>
                                        <th>İşlem</th>
                                    </tr>
                                </thead>
                                <tfoot>
                                    <tr>
                                        <th>Kullanıcı adı</th>
                                        <th>Ad</th>
                                        <th>Soyad</th>
                                        <th>İşlem</th>
                                    </tr>
                                </tfoot>
                                <tbody>
                                    <?php foreach($users as $row): ?>
                                    <tr>
                                        <td><?=$row->username?></td>
                                        <td><?=$row->name?></td>
                                        <td><?=$row->surname?></td>
                                        <td>
                                            <a href="<?=base_url('admin/delete/'.$row->id.'/users');?>"
                                                class="btn btn-danger" style="color: #fff">Sil</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>
<?php $this->load->view('inc/bottom');?>