-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 19 May 2020, 14:34:20
-- Sunucu sürümü: 10.4.11-MariaDB
-- PHP Sürümü: 7.3.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `mithaber`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `categories`
--

INSERT INTO `categories` (`id`, `name`, `slug`) VALUES
(1, 'Mobil', 'mobil'),
(2, 'Otomobil', 'otomobil'),
(3, 'Oyun', 'oyun'),
(4, 'Sektörel', 'sektorel'),
(5, 'Sinema', 'sinema-dizi');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `postID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `contacts`
--

CREATE TABLE `contacts` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `contacts`
--

INSERT INTO `contacts` (`id`, `email`, `subject`, `message`, `createdAt`) VALUES
(1, 'ali.kavakli4598@gmail.com', 'konu', 'mesaj', '2020-05-19 10:59:27');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `categoryID` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `createdAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `posts`
--

INSERT INTO `posts` (`id`, `categoryID`, `title`, `slug`, `img`, `content`, `createdAt`) VALUES
(1, 1, 'Samsung, Fiyatı Uygun Olursa Peynir Ekmek Gibi Satacak Galaxy A21s’i Tanıttı', 'samsung-galaxy-a21s-ozellikleri', 'https://www.webtekno.com/images/editor/default/0002/63/6bb10d1ed70442d49cda21f606df1807f0358ea2.jpeg', 'Samsung Galaxy A21s\'in arka kısmında dörtlü kamera kurulumu bulunuyor. Bu kamera kurulumunda 48 MP ana kamera, 8 MP ultra geniş açılı kamera, 2 MP derinlik kamerası ve 2 MP de makro kamera yer alıyor. Telefonun delikli ekranında yer alan ön kamera ise tüketicilere 13 MP çözünürlük sunuyor. Ayrıca bu telefonun arkasına yerleştirilmiş bir parmak izi okuyucu da bulunuyor. \r\n\r\nSamsung\'un giriş-orta seviye telefonu, Android 10 tabanlı One UI 2.0 ile çalışıyor. MicroSD desteğine de sahip olan cihaz, 512 GB\'ye kadar sunduğu destekle tüketicilerin depolama sorunu yaşamasının önüne geçmiş olarak. Ayrıca 5.000 mAh kapasiteli de bir bataryası bulunan Galaxy A21s, tüketicilere 15 watt hızlı şarj desteği sağlıyor. \r\n\r\nSamsung Galaxy A21s\'in arka kısmında dörtlü kamera kurulumu bulunuyor. Bu kamera kurulumunda 48 MP ana kamera, 8 MP ultra geniş açılı kamera, 2 MP derinlik kamerası ve 2 MP de makro kamera yer alıyor. Telefonun delikli ekranında yer alan ön kamera ise tüketicilere 13 MP çözünürlük sunuyor. Ayrıca bu telefonun arkasına yerleştirilmiş bir parmak izi okuyucu da bulunuyor. \r\n\r\nSamsung\'un giriş-orta seviye telefonu, Android 10 tabanlı One UI 2.0 ile çalışıyor. MicroSD desteğine de sahip olan cihaz, 512 GB\'ye kadar sunduğu destekle tüketicilerin depolama sorunu yaşamasının önüne geçmiş olarak. Ayrıca 5.000 mAh kapasiteli de bir bataryası bulunan Galaxy A21s, tüketicilere 15 watt hızlı şarj desteği sağlıyor. \r\n\r\n', '2020-05-15 15:05:47'),
(3, 1, 'Google Chrome\'un Yeni Reklam Engelleme Özelliği, Pil Tasarrufu Sağlayacak', 'google-chrome-reklam-engelleme-pil-tasarrufu-saglayacak', 'https://www.webtekno.com/images/editor/default/0002/63/853253a28080137acfdd29748d064e5f2115fe3a.png', 'Google, Chrome için geliştirdiği yeni reklam engelleme özelliğini ağustos ayında yayınlamayı planlıyor. Chrome, fazlasıyla kaynak tüketen reklamları engellerken aynı zamanda pil tasarrufu da gerçekleştirmiş olacak.\r\nGoogle, ağustos ayında yayınlayacağı yeni bir güncelleme ile Chrome\'un çok fazla kaynak tüketen reklamları otomatik olarak engellemesini sağlayacak. Kullanıcılar tarafından uzun süredir beklenen reklam engelleme özelliği, yalnızca internet sitelerindeki abartı reklamları engellemekle kalmayacak, dizüstü bilgisayar, akıllı telefon ve tablet kullanıcıları için daha uzun bir pil ömrü de sağlayacak.\r\n\r\nGoogle, pil ve ağ verileri gibi kaynakları orantısız şekilde kullanan bir reklam kategorisi belirlediğini açıkladı. Bu reklamlar, kullanıcının bilgisi olmadan madencilik gibi arka plan görevleri gerçekleştirebiliyor. Arama devi, reklam engelleme özelliğiyle bu tarz istismarların önüne geçmeyi planlıyor.\r\n\r\nGoogle Chrome ürün yöneticisi Marshall Vale, blog yazısında yaptığı açıklamada, \"Chrome, kullanıcılarımızın pil ve veri planlarını korumak, onlara web\'de iyi bir deneyim sunmak için reklamların kullanabileceği kaynakları sınırlayacak. Ayrıca bir reklam kaynak kullanımında sınıra ulaştığında, reklamın çerçevesi bir hata sayfasına yönlendirilecek ve kullanıcıya reklamın çok fazla kaynak kullandığını bildirecek.\" ifadelerini kullandı.\r\n\r\nGoogle, \'ağır reklamlar\' olarak adlandırılan bu tür reklamların, tüm reklamların yalnızca %0.3\'ünü oluşturduğunu ancak tüm reklamcılık ağı verilerinin %27\'sini tükettiğini belirtiyor. Bu reklamlar cihazların CPU kullanımının %28\'ini oluşturuyor ve pil ömrünü önemli ölçüde düşürüyor.\r\n\r\nGoogle, reklamlar 4 MB\'den fazla veri tüketirse, CPU\'yu 30 saniyelik periyotlarda 15 saniyeden fazla kullanırsa veya CPU\'yu toplamda bir dakikadan fazla kullanırsa, o reklamları kapatacağını söylüyor. Google\'ın en büyük reklamcılık ağına sahip olduğu göz önüne alındığında Google tarafından sunulan reklamların çok küçük bir kısmının bu durumdan etkileneceğini tahmin edebiliriz.\r\n\r\nGoogle, Chrome tarayıcısı için reklam engellemeyi ağustos ayının sonundan itibaren sunmayı planlıyor. Chrome bu gelişmeyle Opera, Firefox ve Vivaldi gibi mobil ve masaüstü tarayıcılarında bulunan reklam engelleme özelliğini kendi tarayıcılarına da getirmiş olacak.', '2020-05-14 15:35:48'),
(4, 2, 'Volvo CEO’su: Koronavirüs, Elektrikli Araçlara Geçişi Hızlandıracak', 'koronavirus-elektrikli-araclara-gecisi-hizlandiracak', 'https://www.webtekno.com/images/editor/default/0002/63/60d82aa00de5638c60c1e7637b10a716016e497d.jpeg', 'Volvo CEO’su Håkan Samuelsson, koronavirüs salgının atlatılmasının ardından otomotiv endüstrisindeki değişimin hızının artacağını söyledi. Samuelsson, salgından sonra elektrikli araçlara geçişin çok daha hızlı olacağını açıkladı.\r\nKoronavirüs salgını sonrasında dünya, salgın öncesindeki dünyaya benzemeyebilir. Salgın sırasında insanların alışkanlık haline getirdikleri bazı davranışların salgından sonra da devam ettirilmesi bekleniyor. Volvo CEO\'su  Håkan Samuelsson, insanların salgından sonra değiştirecekleri tercihlerinden birinin de araç seçimi olacağını söyledi. \r\n\r\nSalgından önce elektrikli araçların satış rakamları artıyordu. Ancak içten yanmalı motora sahip araçlar hala sektörün en büyük payına sahip durumda. Financial Times’in küresel dijital konferansında konuşan Volvo CEO’su Håkan Samuelsson, elektrikli araçlara artan ilginin salgın sonrasında artarak devam edeceğini söyledi. \r\n\r\nVolvo CEO’su, “Elektrifikasyon daha da hızlı ilerleyecek. Biraz naif olacak ama sanırım birkaç ay sonra her şey normale dönecek ve müşterilerimiz dizel otomobiller almak için showroomlara geri dönecekler. Showroomlara giden müşteriler daha fazla elektrikli araba isteyecekler” dedi.\r\n\r\nİnsanların elektrikli araçlara daha fazla ilgi duyacağını söyleyen Håkan Samuelsson, hükümetlerin otomobil endüstrisinin toparlanması için verecekleri desteğin elektrikli araçlar gibi yeni teknolojilere odaklanması gerektiğini söyledi. \r\n\r\nBüyük şehirlerde özel araçların pratik bir çözüm olmadığını söyleyen Volvo CEO’su daha esnek araç sahipliği modellinin uygulamaya geçirilmesi gerektiğini söyledi. Samuelsson, esnek araç sahipliği modeline örnek olarak düşük maliyetli araç aboneliğini bir seçenek olarak sundu. \r\n\r\nHåkan Samuelsson, salgın nedeniyle kısıtlamalar altında yaşayan insanların e-ticarette deneyim kazandığını belirtti. Samuelsson, artan e-ticaret deneyiminin çevrimiçi araç satın almayı da teşvik edeceğini söyledi. Volvo CEO’su, çevrimiçi araç satışları ile ilgili olarak “Bence otomobil sattığımız ve dağıttığımız yerler değişecek. Zaten değişiyor ama şimdi daha hızlı değişecek” dedi. \r\n\r\nElektrikli araçlar ve çevrimiçi araç satışı konusunda iyimser tahminlere sahip olan Håkan Samuelsson, otonom araçların gelişimi konusunda o kadar iyimser görünmüyor. Birkaç yıl içinde daha gelişmiş otonom araçlar göreceğimizi söyleyen Samuelsson, otonom araçların düşündüğümüz kadar hızlı olmayacağını da sözlerine ekledi. \r\n\r\nVolvo CEO’su Håkan Samuelsson’ın elektrikli araçlarla ilgili açıklamaları, şirketin bu alandaki stratejisini açıklamak konusunda oldukça berrak görünüyor. Volvo, önümüzdeki beş yıl boyunca elektrikli araç endüstrisinde artan bir yer kazanmayı düşünüyor. Otomobil üreticisi bu nedenle 5 yıl içinde her yıl bir elektrikli araç piyasaya sürmeyi planlıyor. Şirket, 2025 yılında elektrikli araçlarının satışının tüm Volvo satışlarının yüzde 50’sini oluşturmasını istiyor. \r\n', '2020-05-15 15:57:51'),
(5, 2, 'Tesla, Üretim Maliyetini Düşürecek Devrimsel Bataryalarını Tanıtmaya Hazırlanıyor', 'tesla-maliyet-dusuren-devrimsel-bataryalar-tanitacak', 'https://www.webtekno.com/images/editor/default/0002/62/fcd30b44cf3df9a3df6bc0f04fb1cd58aaef5ee5.jpeg', 'Günümüzün en büyük elektrikli otomobil üreticisi Tesla, Autoblog’un haberine göre bu ayın sonlarında yeni bataryasını tanıtacak. Şirketin tanıtacağı batarya, günümüz bataryalarından hem daha ucuz hem de daha uzun ömürlü olacak.\r\nTesla CEO’su Elon Musk, geçtiğimiz birkaç haftadır şirketin mayıs ayı sonlarındaki ‘batarya gününde’ yepyeni bir batarya teknolojisini göstereceği hakkında bazı paylaşımlar yapıyordu. Görünüşe göre Musk’ın tüm paylaşımları yakın bir zamanda yerini bulacak ve Tesla, yeni teknolojisini açıklayacak.\r\n\r\nElektrikli otomobil üreticisi Tesla, Autoblog’un haberine göre bu yılın ilerleyen zamanlarında veya 2021’in başında Çin’deki Model 3\'lerde yeni bir batarya kullanacak. Şirketin kullanacağı bu bataryanın maliyeti günümüz bataryalarından çok daha ucuz olacak ve aynı zamanda bataryanın ömrü de daha uzun olacak.\r\n\r\nAutoblog’a göre Tesla’nın tanıtacağı yeni batarya teknolojisiyle birlikte elektrikli otomobillerin toplam maliyeti de azalacak. Ayrıca habere göre şirketin yeni bataryası, Tesla otomobillerin bir milyon mile (1.609.344 kilometre) kadar hiçbir sorun çıkarmadan yollarına devam etmesini sağlayacak.\r\n\r\nTesla’nın bir milyon millik ömre sahip yeni bataryası, Çinli Contemporary Amperex Technology (CATL) şirketiyle birlikte ortaklaşa geliştirildi. İlk olarak Çin’deki Tesla’larda kullanılması planlanan yeni, düşük maliyetli ve uzun ömürlü bataryalar, daha sonra Tesla’nın bulunduğu diğer pazarlarda da kendisini gösterecek.\r\n\r\nPeki Tesla’nın yeni bataryası bu özellikleri nasıl sağlayacak? Gelen bilgilere göre yeni batarya, az kobaltlı ve kobalttan yoksun batarya yapılarından yararlanacak. Bununla birlikte bataryaya eklenen kimyasal katkılar, materyaller ve kaplamalar; bataryanın içindeki gerilimi azaltacak ve daha fazla enerji depolamalarını sağlayacak.\r\n\r\nŞirket, yeni bataryasının yanı sıra yüksek hızlı ve büyük oranda otomatikleştirilmiş yeni batarya üretim sürecini de devreye sokmayı planlıyor. Şirket, bu sayede daha az işçi çalıştıracağından bu yönden de bir tasarruf sağlayacak. Ayrıca şirketin Gigafactory’sinden 30 kat daha büyük olan Terafactory’lerinde üretim daha da artacak.', '2020-05-15 15:59:48'),
(6, 3, 'GTA 5 Online\'ın Yeni Güncellemesi, Ücretsiz Silahlar ve Bonus Ödüllerle Geldi', 'gta-5-online-ucretsiz-silah-bonus-odul', 'https://www.webtekno.com/images/editor/default/0002/63/a57f51a7b3220220b1edb0dcbfa7fd6696a6784e.jpeg', 'GTA 5\'in ücretsiz olmasının ardından, GTA Online\'a katılacak yeni oyuncuların Los Santos\'ta hızla yükselmesini sağlayacak haftalık güncelleme yayınlandı. Yeni güncellemeyle birlikte oyunculara ücretsiz silahlar, bonus ödüller ve büyük indirimler sunuluyor.\r\nGTA 5\'in Epic Games Store\'da ücretsiz olması, mağaza sayfasını çökertecek kadar geniş yankı buldu. Dev kampanyanın hemen ardından Rockstar, yıllara meydana okuyan oyunu GTA 5\'in çevrimiçi modu olan GTA Online için ücretsiz silahlar ve bonus ödüller içeren yeni haftalık güncelleme yayınladı.\r\n\r\nRockstar, GTA Online\'da Gunrunning Sell Görevleri ve Bunker Serisine bağlı görevlerde tüm ödülleri ikiye katlayarak yeni oyunculara hızlı bir başlangıç yapmaları için yardımcı oluyor. Oyuncular, hafta boyunca GTA Online\'da ücretsiz tabancalar alabilecek ve bonus ödüllerle ekstra GTA $ ve RP kazanabilecek.\r\n\r\nGTA Online\'da yeni bir tabanca isteyenler veya silaha ihtiyaç duyan yeni oyuncular Ammu-Nation\'dan ücretsiz tabancalar alabiliyor. Sidearm Week etkinliği kapsamında tüm tabancalar mağazada ücretsiz olarak sunuluyor. Eğer bu fırsattan yararlanmak istiyorsanız 21 Mayıs\'a kadar Ammu-Nation\'a giderek ücretsiz silahlarınızı alabilirsiniz.\r\n\r\nBunker Serisi görevleri şu anda tamamladıkları takdirde bonus ödüller veriyor. Oyuncular, Los Santos\'un derin ve karanlık yeraltı dünyasına girerek iki kat daha fazla GTA $ ve RP alma şansı yakalayabiliyorlar. Ayrıca Research Speed ve Gunrunning Sell etkinlikleri de iki kat ödül sunuyor. Yasa dışı silah kaçakçılığıyla da büyük bonuslar kazanabilirsiniz.\r\n\r\nLucky Wheel büyük ödülü de yeni güncellemeyle birlikte bir kez daha değiştirildi. Diamond Casino & Resort\'ta şansınızı deneyerek Urban Racer kaplaması ile özelleştirilmiş Grotti Itali GTO\'yu garajınıza ekleyebilirsiniz. Ayrıca çarkı her gün ücretsiz döndürerek oyun içi para ödülleri de elde edebilirsiniz.\r\n\r\nEğer kendinize yeni bir araba bakmak isterseniz Progen Emerus, HVY Nightshark, Överflöd Entity XXR ve Karin Sultan RS\'te de %40\'a varan indirimler var. Los Santos\'taki sığınaklarda da (Bunkers) %40 indirim sunuluyor. Ayrıca Bunker yükseltmeleri ve eklentileri de %30 indirimli. Twitch Prime üyeleri, Tula uçağında %80 indirim ve Grotti Furia\'da %60 indirimin yanı sıra oyun içi eşyalarda bonus indirimlerinin tadını çıkarabilecekler.\r\n\r\nBu ay boyunca GTA Online ve Red Dead Online\'da yapılan tüm çevrimiçi satın alma işlemlerinin gelirleri Rockstar ve Take-Two aracılığıyla koronavirüse karşı mücadele veren sağlık kurumlarına bağışlanacak.', '2020-05-15 16:01:25'),
(7, 3, 'Peyo\'nun Çizgi Romanlarına Dayanan Yeni Bir Şirinler Oyunu Geliyor', 'yeni-sirinler-oyunu-yolda', 'https://www.webtekno.com/images/editor/default/0002/63/01e5c90dddf5857b8d248e82d4c5234362f20191.jpeg', 'Asterix & Obelix XXL serisinin geliştiricisi OSome Studio, şimdi de Şirinler oyunu üzerinde çalışıyor. Oyun, Şirinler\'in yaratıcısı Peyo\'nun çizgi romanlarına dayanan orijinal bir deneyim sunacak.\r\nBüyük küçük herkesin sevgilisi olan Şirinler, yepyeni bir oyunla karşımıza çıkmaya hazırlanıyor. Yayıncı Microids ve küçük mavi yaratıkların lisans haklarını elinde tutan IMPS, yeni bir Şirinler oyunu için yayıncılık anlaşması imzaladığını açıkladı. Oyun, Asterix & Obelix XXL serisi üzerinde çalışan OSome Studio tarafından geliştiriliyor.\r\n\r\n60 yıl önce Belçikalı karikatürist Peyo tarafından çizilen Şirinler, büyüleyici evreni ve ikonik karakterleri sayesinde birçok nesle damgasını vurdu. Çizgi romanlara, animasyon dizilerine ve hatta filmlere uyarlanan Şirinler, oyun dünyasında da zaman zaman karşımıza çıkıyordu. Ancak mavi kahramanlar, bu kez her zamankinden daha gelişmiş bir oyunla karşımıza çıkacak.\r\n\r\nŞirinler oyunu yeni bir hikayeye sahip olacak ve mizah, heyecan, gerilim ve aksiyon unsurlarını bir araya getirecek. Geliştiriciler, Peyo\'nun çizgi romanlarından esinlenen oyunda 3 boyutlu aksiyon macera türünde yepyeni bir deneyim sunmayı hedefliyor. Yani oyun, orijinal Şirinler\'e büyük ölçüde bağlı kalacak. Oyuncular, Şirinler oyununda tek başlarına veya arkadaşlarıyla birlikte, sevilen kahramanlarının yer aldığı özel bir macerayı deneyimleyecek.\r\n\r\nMicroids, ortak stüdyosu OSome Studio sayesinde, oyuncuları Şirinler\'in harika dünyasında bir araya getireceklerinden emin olduğunu belirtti. IMPS başkanı ve aynı zamanda Şirinler\'in yaratıcısı Peyo\'nun kızı olan Veronique Culliford, \"Bu güzel ortaklıktan çok mutluyum. Video oyunları her zaman tutkum oldu, çünkü oyunculuğu ve sıklıkla öğrenmeyle birleştiriyorlar.\" şeklinde konuştu. Yeni Şirinler oyununun geleceği platformlar veya çıkış tarihi hakkında henüz bir açıklama yapılmadı.', '2020-05-15 16:02:22'),
(8, 4, 'Xiaomi, Fırsatlarla Dolu Yeni Kredi Kartını Tanıttı', 'xiaomi-yeni-kredi-karti-tanitildi', 'https://www.webtekno.com/images/editor/default/0002/62/f4ee5f24cfde9270494ec0a07433a966aaf1418b.png', 'Çinli teknoloji üreticisi Xiaomi; UnionPay ve GF Credit Card ile yaptığı iş birliğinin bir sonucu olarak yeni Xiaomi GF Joint kredi kartını tanıttı. Kart, Xiaomi alışverişlerinde avantajlar sağlayabiliyor.\r\nSon dönemde teknoloji üreticileri gözlerini finans teknolojilerine dikmiş durumda. Blok zincir ve kripto para gibi yeni teknolojileri bir yana koysak bile NFC ve akıllı kartlar gibi geleneksel yöntemlerin üzerine inşa edilmiş sistemler de karşımıza çıkıyor.\r\n\r\nGeçtiğimiz dönemlerde Apple, kendi yeni ön ödemeli kartını duyurmuştu. Benzer bir hamle de Çinli üretici Xiaomi’den geldi. Xiaomi; UnionPay ve GF ile iş birliği yaparak ürettiği yeni kredi kartının duyurusunu gerçekleştirdi.\r\n\r\nYeni kart, Xiaomi’nin kullanıcılara yönelik ilk küçük ev elektroniği ödeme aracı olarak gösteriliyor. Kartın bir diğer özelliği de bu kartla her ay üç defa 199 yuanlık (yaklaşık 195 TL) alışveriş yapanlara her ay bir adet aynı bedelde ürün hediye edilmesi.\r\n\r\nİlk gelen bilgilere göre kartlar özel bir materyalden yapılacak. Kart üzerindeki bilgiler lazer işlemeyle yazılacak. Karta başvuru yapmaksa oldukça kolay olacak. Xiaomi telefonlarda yer alan Xiaomi Cüzdan uygulamasından karta başvuru yapılabilecek. Xiaomi telefon kullanmıyorsanız Xiaomi Cüzdan hesabıyla başvuru yapmanız gerekecek. Bu kartla teknik olarak NFC özelliği olmayan cihazların da akıllı cüzdan kullanması sağlanacak. Tabii bunun ilk aşamada Çin\'de kullanılacağını belirtelim.\r\n\r\nXiaomi, yeni kartının tanıtımını yapmak ve müşteriler tarafından kullanılmasını sağlamak için bazı kampanyalar da hazırladı. Buna göre ilk üç ay içerisinde 99 yuanlık bir alışveriş yapmanız durumunda 50 yuanlık bir Xiaomi indirim çeki kazanıyorsunuz. Bu da ödediğiniz bedelin neredeyse %50\'sini başka bir üründe değerlendirebileceksiniz demek.\r\n\r\nBu kartlar ayrıca birikim ve faiz hesaplarıyla birlikte de çalışıyor. Kartlar, çeşitli firmaların sahip olduğu ön ödemeli kartlarla ya da ön ödemeli uygulamalarla da sorunsuz şekilde kullanılabiliyor. Kartın farklı avantajları da olması bekleniyor. Şu anda kartın Çin’de kullanılabileceği biliniyor. Xiaomi ve Apple gibi firmaların kartlar üretmeye başlaması hakkında ne düşünüyorsunuz? Sizce bu teknolojiler hayatımızı nasıl etkileyecek?', '2020-05-15 16:03:34'),
(9, 4, 'Intel, 10 Yıllık Planlama İçeren \'Kurumsal Sorumluluk Raporu\'nu Yayınladı', 'intel-kurumsal-sorumluluk-raporu', 'https://www.webtekno.com/images/editor/default/0002/62/a475c942b7046a139d40a092adfc0010de2188b4.png', 'Intel, Kurumsal Sorumluluk Raporu\'nun bu yılki versiyonunu bugün yayınladı. Yayında, Intel\'in koronavirüs salgınıyla mücadeledeki çabalarına dikkat çekiliyor. Öte yandan yine raporda Intel\'in 2030\'a kadar faaliyetlerini belirleyecek 10 yıllık planın ayrıntıları da yer alıyor.\r\nKoronavirüs salgını, birçok teknoloji devini salgınla mücadelede inisiyatif almaya yöneltti. Dünyanın en büyük yarı iletken üreticisi olan ABD\'li Intel de yıllık olarak açıkladığı Kurumsal Sorumluluk Raporu\'nun (CRR) 2020 versiyonunda, salgınla mücadelede şirketin oynadığı role dikkat çekiyor.\r\n\r\nRaporda şirketlerin dünyada meydana gelen zorluklarla mücadelede iş birliği yaklaşımını geliştirmesi gerektiği ve bunun için koronavirüs salgınının iyi bir örnek oluşturabileceği vurgulanıyor. Intel\'in bu kapsamda şimdiye kadar sağlık çalışanlarına ve yerel topluluklara destekle birlikte salgınla mücadelede ihtiyaç duyulan teknolojilere erişimi hızlandırmak için 60 milyon doların üzerinde yardım yaptığı belirtiliyor. Yine COVID-19\'la mücadele kapsamında Intel, çalışanlarına ek olarak 100 milyon dolar ödeme yaptı.\r\n\r\n80 sayfalık raporda 10 yıllık plan kapsamında hedeflenen 2030 stratejisinin ayrıntılarına yer verilirken sürdürülebilir uygulamalara uyum sağlamanın hızlandırılması da hedefleniyor. Rapora göre Intel\'in öncelikleri arasında iklim değişikliği ile iş yerinde katılım ve çeşitlilik gibi başlıklar da yer alıyor.\r\n\r\nIntel; üretimde, ulaştırmada ve sağlık hizmetlerinde teknolojiyi kolaylaştırmak için sağlık, yaşam bilimleri ve devletlerle ortaklıklar planlıyor. Bu planlara; hastalıklara tedavi bulmak ve sağlık hizmetlerini iyileştirmek de dâhil. Intel\'in bu konudaki son örneği, COVID-19\'u teşhis ve tedavide bulut, yapay zekâ ve yüksek performanslı teknoloji çözümlerini uyguladığı Pandemi Müdahale Teknoloji Girişimi.\r\n\r\nHedeflerinin bir hayli yüksek olduğunun farkında olan Intel\'in kurumsal sorumluluk yöneticisi Suzanne Fallender, bundan yaklaşık 10 sene önce 2020 planlarını hazırlarken de bu planların fazlasıyla hırslı olduğunun farkında olduklarını kaydetti. Fallender, COVID-19\'la birlikte başkalarıyla iş birliği yapmanın kritik öneminin ortaya çıktığını söylerken bunu salgın süresince gerçek zamanlı olarak öğrendiklerini ve bir sonraki adımlarında uyguladıklarını belirtti. Yönetici, son 10 yılda Intel\'in bilgisayar merkezli bir şirket olmaktan çıkarak veri merkezli bir şirket hâline dönüştüğüne de dikkat çekti.\r\n\r\nBu kapsamda karbon salınımlarını birim başına %39 azalttıklarını kaydeden Fallender, yine birim başına su kullanımını da %38 azalttıklarını belirtti. Yönetici, iş yerinde kadın ve yeterli oranda temsil edilmeyen azınlıkların temsili söz konusu olduğu bu hedeflerine takvimden 2 sene önce eriştiklerini de sözlerine ekledi.\r\n\r\nŞirketin 2030 yılı hedefleri arasında net pozitif su kullanımı, %100 yeşil enerji ve Intel\'in küresel imalat operasyonlarında sıfır atık gibi hedefler yer alıyor. Şirket; sağlık ve güvenliği teknoloji aracılığıyla iyileştirmeyi; teknolojiyi tamamen kucaklayıcı hâle getirmeyi; iklim değişikliğiyle mücadele için karbonsuz çalışmayı başarmayı hedefliyor. Raporun tamamına buradan ulaşabilirsiniz.\r\n\r\n', '2020-05-15 16:04:21'),
(10, 1, 'Nokia 6.3\'ün Sanılandan Daha Güçlü Bir Telefon Olacağını Ortaya Koyan İddia', 'nokia-6-3-guclu-telefon-olabilir', 'https://www.webtekno.com/images/editor/default/0002/63/91d420652d65b55ac753537550de92da1a088601.jpeg', 'HMD Global\'in bir sonraki orta seviye telefonunun Nokia 6.3 olacağı konuşuluyor. Nokia\'ya yakın olduğunu iddia eden bir kaynak, Nokia 6.2\'nin halefi olarak geleceği düşünülen telefonun işlemcisi ve kamera kurulumu hakkında yeni iddialar ortaya attı.\r\nHMD Global, son dönemde Nokia 6.3 olarak adlandırılan bir telefonla anılıyor. Ortaya çıkan ilk söylentiler, Nokia 6.3\'ün Snapdragon 670 veya Snapdragon 675 işlemcilerden biriyle geleceğini öne sürüyordu. Ancak yeni bir iddia, daha güçlü bir işlemciyi işaret ediyor.\r\n\r\nNokia\'nın yaklaşmakta olan 6.3 isimli yeni akıllı telefonunda her ne kadar Snapdragon 67X işlemci kullanılacağı öne sürülse de HMD Global\'e yakın olduğunu iddia eden bir kaynak, telefonun aslında Snapdragon 730 işlemciye sahip olacağını belirtiyor. Kaynak ayrıca telefonun diğer bazı özelliklerine de ışık tuttu.\r\n\r\nDaha önceki iddialar, Nokia 6.3\'ün 16 MP ana kamera, 8 MP ultra geniş açılı kamera ve 5 MP derinlik sensörünün olacağını söylüyordu. Ancak yeni iddialar akıllı telefonun 24 MP ana sensör, 12 MP ultra geniş sensör, 2 MP derinlik ve 2MP makro kamerayı barındıran dörtlü bir kurulumla geleceğini ortaya koydu.\r\n\r\nSon olarak kaynak, Nokia 6.3\'ün güç düğmesine entegre edilmiş bir parmak izi tarayıcısı olacağını iddia ediyor. Yani Nokia 6.3, tek elle kullanım düşünülerek tasarlanmış kompakt bir telefon olarak karşımıza çıkabilir. Yeni Nokia telefonun 2020 yılının üçüncü çeyreğinde gerçekleştirilecek bir lansmanla tanıtılması bekleniyor. Nokia 6.3\'ün selefi olan Nokia 6.2, geçen yıl ekim ayında tanıtılmıştı. Tüm bunların yanı sıra bazı söylentiler telefonun 3 GB RAM ve 64 GB depolama alanı sunacağını, fiyatının da 249 euro olacağını öne sürüyor.', '2020-05-15 16:18:43'),
(11, 1, 'Apple, Bu Yıl İçinde Uygun Fiyatlı 10 İnç iPad Duyurabilir', 'apple-uygun-fiyatli-10-inc-ipad-duyurabilir', 'https://www.webtekno.com/images/editor/default/0002/63/990521d922883a92d2760ddc914b55245dee546b.jpeg', 'Apple’ın gelecek ürünlerine dair güvenilir raporlar yayınlayan Apple analisti Ming-Chi Kuo, Apple’ın 2020’nin ikinci yarısında uygun fiyatlı bir 10.8 inç iPad piyasaya süreceğini iddia etti. Kuo, 2021 başında daha büyük ekrana sahip bir iPad mini’nin de duyurulacağını öne sürdü.\r\nGeçtiğimiz haftalarda Apple’ın, sonbaharda tanıtılması beklenen yeni iPhone serisini salgın nedeniyle zamanında tanıtamayacağı ve lansmanı erteleyeceği ddia edilmişti. Ancak ortaya çıkan yeni söylentiler, Apple’ın yeni iPhone’ları zamanında tanıtacağını belirtirken, şirketin 2020 sonu ve 2021 başında iki yeni iPad piyasaya süreceğini de ortaya koyuyor. \r\n\r\nApple’ın yeni ürünleri hakkında isabetli tahminler yapan Apple analisti Ming-Chi Kuo, teknoloji devinin 2020’nin ikinci yarısında uygun fiyatlı 10.8 inç iPad duyuracağını öne sürdü. Kuo, uygun fiyatlı olacak 10 inç iPad’in tıpkı iPhone SE’de olduğu gibi Apple’ın en yeni işlemcisini kullanacağını belirtiyor.\r\n\r\nKuo’nun yayınladığı raporda yeni iPad mini ile ilgili bir iddia da bulunuyor. Ünlü Apple analisti, Apple’ın 2021 başında mevcut 7.9 inç iPad mini’den daha büyük ekrana sahip 8.5 veya 9 inç boyutlarında bir iPad mini piyasaya süreceğini öne sürdü. \r\n\r\nMing-Chi Kuo, yeni iPad modellerinin fiyatları konusunda herhangi bir bilgi yayınlamadı. Ancak şu an en uygun fiyatlı olan 10 inç iPad modeli 329 dolar fiyat etiketine sahip. Uygun fiyatlı yeni 10 inç iPad’in bu fiyatın altında bir satış fiyatına sahip olması bekleniyor. \r\n\r\nKuo, Apple’ın artırılmış gerçeklik gözlükleri olması beklenen Apple Glasses hakkında da tahminlerde bulundu. Kuo, Apple Glasses’ın 2020 yılında piyasaya sürüleceğini açıkladı. Ancak Apple Glasses, yeni iPad\'in aksine uygun fiyatlı değil bilhassa pahalı bir ürün olacak.\r\n\r\nMing-Chi Kuo’nun Apple\'ın tedarik zincirindeki kaynaklarını göz önüne aldığımızda ünlü analistin iddialarına kulak tıkayamayız. Kuo, son olarak Apple’ın uygun fiyatlı bir yeni iPhone’u olan iPhone SE’nin gelişini ve pek özelliğini aylar öncesinden tahmin etmişti.', '2020-05-15 16:19:48'),
(12, 1, 'Lenovo Legion\'un Dikeyden Çok Yatay Kullanılacağını Gösteren Tanıtım Videosu', 'lenovo-legion-yatay-kullanim-tanitim-videosu', 'https://cdn.webtekno.com/media/cache/content_detail_v2/article/92476/yatay-telefon-kullanimini-benimsetmek-isteyen-lenovo-dan-legion-icin-yeni-tanitim-videosu-1589525516.jpg', 'Lenovo\'nun bir süredir üzerinde çalıştığı yeni oyuncu telefonu Legion ile ilgili yeni bir tanıtım videosu daha paylaşıldı. Telefonun yatay kullanımdaki arayüzünü ortaya koyan tanıtım videosu, içerdiği ifadeler ile fazlasıyla iddialı olduğunu ortaya koyuyor.\r\nÇinli teknoloji devi Lenovo, bir süredir üzerinde çalıştığı oyuncu telefonu Legion için yeni bir tanıtım videosu paylaştı. Paylaşılan yeni video, önceki tanıtımlarda olduğu gibi cihazın dikey değil yatay kullanım için geliştirildiğinin altını çiziyor.\r\n\r\nLenovo\'nun Legion ile ilgili daha önce yaptığı paylaşımlar, cihazın yatay olarak yerleştirilmiş bir ön kameraya sahip olacağını ortaya koyuyordu. Şirketin yeni tanıtım videosu da bu tasarım ile paralel şekilde Lenovo Legion\'ın tamamen yatay kullanılabileceğini ortaya koyuyor. Çünkü Lenovo, Legion\'ın arayüzünü yatay kullanıma en iyi şekilde uyum sağlaması için özel olarak optimize etmiş.\r\n\r\nLenovo tarafından oluşturulan yeni tanıtım videosu, iddialı bir açıklamaya da sahip. Yetkililer, hazırladıkları videoda Legion\'ın görsel deneyimi en üst seviyeye getireceğini ifade ediyorlar. Yani Lenovo\'nun Legion ile ilgili planları, en azından şirket tarafından ciddi bir şekilde önemseniyor gibi görünüyor.\r\n\r\nLenovo, Legion\'ın çıkış tarihi ile ilgili henüz bir açıklama yapmadı. Ancak şirket, son birkaç ayını yeni akıllı telefonuna ayırdı ve bu telefonun mümkün olan en iyi deneyimi sunması için çalışmalarını sürdürüyor. Telefonla ilgili olarak keşfetmemiz gereken hala pek çok şey var ancak Lenovo, günler geçtikçe yeni telefonuyla ilgili daha fazla detayı ortaya koyacaktır.', '2020-05-15 16:21:14'),
(13, 2, 'Hyundai, Elektrikli Otomobiller İçin Sanal Motor Sesi Sistemi Geliştirdi', 'hyundai-elektrikli-otomobil-sanal-motor-sesi', 'https://www.webtekno.com/images/editor/default/0002/62/59bc67c71f5670c07caaa21b8c1d57bac5816a6e.jpeg', 'Güney Koreli otomobil üreticisi Hyundai, elektrikli araçlar için sanal motor sesi sistemi geliştirdi. Izgara kapağı şeklinde tasarlanan bir hoparlör, sürüş esnasında çıkaracağı yapay ses ile yaya ve bisikletlilerin yaklaşan araçları algılamasını sağlayacak.\r\nİçten yanmalı bir motora ve egzoz çıkışına sahip olmadığı için sürüş esnasında herhangi bir ses çıkarmayan elektrikli otomobiller, bu özellikleri ile zaman zaman tartışmalara neden oluyor. Zira bu sessizlik, yayalar ve bisiklet sürücüleri gibi yolun diğer unsurlarının, kendilerine arkadan yaklaşan bir aracı fark etmemelerine sebebiyet veriyor. \r\n\r\nAvrupa Birliği, meydana gelebilecek kazaların önüne geçmek amacıyla 1 Temmuz 2019 tarihi itibarıyla elektrikli araçlarının düşük hızlarda ilerlerken ‘Akustik Araç Uyarı Sistemi (AVAS)’ adı verilen sisteme sahip olmalarını zorunlu kılmıştı. Kısacası, içten yanmalı motorlara sahip olmayan elektrikli araçların, yapay da olsa yaya ve bisikletlileri uyarmak için ses çıkarması gerekiyor.\r\n\r\nGüney Koreli otomobil üreticisi Hyundai’ın parça tedarikçisi olan Hyundai Mobis, ızgara kapağını kullanarak elektrikli araçlar için akustik araç uyarı sesi ses sistemi geliştirdiğini açıkladı. Genelde tüm elektrikli araçların önünde, açık tip ızgara bulunan içten yanmalı motorlu bir otomobilin aksine, tamamen kapalı bir ön ızgara bulunur. Bu bileşeni hoparlör şeklinde tasarlayan şirket, böylece aracın sahte motor sesi çıkararak yayaları uyarmasını sağlayacak.\r\n\r\nSanal motor sesi sisteminin müzik için de kullanılabileceğini söyleyen Hyundai Mobis, söz konusu özelliğin kamp gibi açık hava etkinlikleri için harika olduğunu belirtti. Söz konusu teknolojinin 2018 yılından bu yana geliştirildiğini açıklayan Güney Koreli firma, sistemle ilgili iki patentin tescil edildiğini bildirdi. ', '2020-05-15 16:23:18'),
(14, 2, 'Türk Tasarımcıdan Nefes Kesen Bugatti Konsepti: La Finale', 'turk-tasarimci-bugatti-la-finale-konsept-tasarim', 'https://www.webtekno.com/images/editor/default/0002/62/dbfcf2336079e27d7681ce03828a214d2dc145e4.jpeg', 'Tasarımcı Serkan Budur, Bugatti\'nin içten yanmalı motora sahip son otomobilini sanal ortamda yeniden tasarladı ve bu dijital modele \'Bugatti La Finale\' adını verdi. Yeni tasarımda Chiron\'dan Type 57SC Atalante\'ye ve Type 41 Royale\'a kadar bazı eski Bugatti modellerinden esinlenilmiş.\r\nFransız otomobil üreticisi Bugatti, 1.500 beygir gücü civarında güç üreten W16 motorlu araçlarıyla çeşitli rekorlara da imza atarken ürettiği otomobillerin neredeyse tamamı akıllarda yer etti. Teknolojik olarak değişen otomotiv sektörüyle birlikte Bugatti de diğer birçok otomobil ve süper otomobil üreticisi gibi içten yanmalı motorları bırakarak hibrit ve elektrikli motorlara geçiş yapmak durumunda kaldı.\r\n\r\nTasarımcı Serkan Budur, Bugatti\'nin içten yanmalı motora sahip son otomobilini dijital ortamda yeniden tasarlayarak render çalışmasını ortaya koydu. Bu çalışmaya verilen isimse \'Bugatti La Finale.\' \r\n\r\nAracın tasarımına bakıldığında mevcut Bugatti modellerinden bazı esintiler görülüyor. Dijital tasarımın ön ızgara kısmı ve agresif ön yüzü Chiron\'a benzerlik gösterirken Bugatti\'nin çok eski modellerinden biri olan Type 57SC Atalante\'den de bazı noktalarda esintilere yer veriliyor. Aracın arka kısmındaki bronz detaylarsa Type 41 Royale adlı eski bir model düşünülerek hazırlandı.\r\n\r\nÖte yandan tasarımcı Serkan Budur, dijital olarak hayal ettiği yeni Bugatti La Finale\'yi Chiron ve Veyron gibi modellerde bulunan W16 motorun aksine, V12 motorla karşımıza çıkarıyor. Tasarımcıya göre böyle bir araçta motorun yerleşeceği alanın daha dar ve aracın biraz daha hafif olması gerekiyor.\r\n\r\nGeçtiğimiz haftalarda Bugatti’nin hiper otomobili Veyron 15. yaşını kutlamıştı. Bugatti’nin imza modeli Veyron, her otomobil gibi ilk olarak kağıt üstünde kendisini gösterdi. Veyron’un çizimleri, Volkswagen Group’un CEO’luğunu yapmış olan yetenekli mühendis Ferdinand Karl Piëch’ten çıkmıştı. Ferdinand Karl Piëch, otomobilin ilk çizimlerini Tokyo ve Nagoya arasında trende seyahat ederken çizmişti. Pek çok otomobil tutkunu için Bugatti yalnızca bir otomobil üreticisi değil, aynı zamanda da bir otomobil sanatçısı konumunda. Sanatçının sayfasını bağlantı aracılığıyla ziyaret edebilirsiniz.', '2020-05-15 16:24:37');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `facebook` varchar(255) NOT NULL,
  `twitter` varchar(255) NOT NULL,
  `instagram` varchar(255) NOT NULL,
  `about` text NOT NULL,
  `logo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `settings`
--

INSERT INTO `settings` (`id`, `facebook`, `twitter`, `instagram`, `about`, `logo`) VALUES
(1, 'http://facebook.com/#', 'http://twitter.com/ali_kvkli', 'http://instagram.com/ali_kvkli', 'Bu script Angular9 kullanılarak geliştirilmiştir. Restfull apileri php ile yazılmıştır.', '');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `role` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `name`, `surname`, `role`) VALUES
(1, 'admin', 'ali.kavakli4598@gmail.com', '123456', 'ali', 'kavaklı', 1);

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Tablo için AUTO_INCREMENT değeri `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Tablo için AUTO_INCREMENT değeri `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Tablo için AUTO_INCREMENT değeri `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Tablo için AUTO_INCREMENT değeri `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
